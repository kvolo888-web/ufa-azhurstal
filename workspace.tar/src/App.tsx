import { useCallback, useEffect, useState } from "react";
import { Check } from "lucide-react";
import { CartProvider, useCart } from "./context/CartContext";
import Header, { type NavigateFn, type Page } from "./components/Header";
import Footer from "./components/Footer";
import Home from "./components/Home";
import About from "./components/About";
import Reviews from "./components/Reviews";
import Delivery from "./components/Delivery";
import ConfiguratorModal from "./components/ConfiguratorModal";
import CartDrawer from "./components/CartDrawer";
import type { Product } from "./data/catalog";

function readPage(): Page {
  const h = window.location.hash.replace(/^#\/?/, "");
  return h === "about" || h === "reviews" || h === "delivery" ? h : "home";
}

function scrollAnchor(anchor: string) {
  document.getElementById(anchor)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function Shell() {
  const [page, setPage] = useState<Page>(readPage);
  const [configurator, setConfigurator] = useState<Product | null>(null);
  const { toast } = useCart();

  useEffect(() => {
    const onHash = () => setPage(readPage());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [page]);

  const navigate = useCallback<NavigateFn>((p, anchor) => {
    const hash = p === "home" ? "#/" : `#/${p}`;
    if (window.location.hash === hash) {
      setPage(p);
      if (anchor) scrollAnchor(anchor);
    } else {
      window.location.hash = hash;
      if (anchor) window.setTimeout(() => scrollAnchor(anchor), 120);
    }
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header page={page} onNavigate={navigate} />

      <main className="grow">
        {page === "home" && (
          <Home onConfigure={setConfigurator} onNavigate={navigate} />
        )}
        {page === "about" && <About />}
        {page === "reviews" && <Reviews />}
        {page === "delivery" && <Delivery />}
      </main>

      <Footer onNavigate={navigate} />

      <ConfiguratorModal product={configurator} onClose={() => setConfigurator(null)} />
      <CartDrawer />

      {/* зернистая плёнка поверх всего — фирменная «окалина» */}
      <div className="noise-overlay" aria-hidden="true" />

      {/* тост-уведомление */}
      {toast && (
        <div
          key={toast.id}
          className="toast-in fixed bottom-6 left-1/2 -translate-x-1/2 z-[70] flex items-center gap-2.5 chamfer-sm bg-iron-850 border border-ember-500/70 px-5 py-3 shadow-[0_10px_40px_-8px_rgba(232,132,31,0.5)]"
        >
          <span className="grid place-items-center w-6 h-6 rounded-full bg-ember-500 text-iron-950">
            <Check className="w-3.5 h-3.5" />
          </span>
          <span className="font-bold text-[14px] text-forge-100">{toast.text}</span>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <Shell />
    </CartProvider>
  );
}
