import { useEffect, useState } from "react";
import {
  Building2,
  Check,
  Clock,
  Copy,
  Flame,
  Hammer,
  Users,
  Mail,
  MapPin,
  Phone,
  Play,
  X,
} from "lucide-react";
import { FORGE_IMAGE, IMAGE_FALLBACK } from "../data/catalog";
import { CONTACTS, PARTNERS, REQUISITES, VIDEOS, type VideoItem } from "../data/content";
import { useReveal } from "../hooks/useReveal";

const NUMBERS = [
  { value: "600 м²", label: "цех с тремя горнами и покрасочной камерой" },
  { value: "12", label: "кузнецов, сварщиков и монтажников в штате" },
  { value: "2009", label: "год первой раскалённой заготовки" },
];

function onErrorImg(e: React.SyntheticEvent<HTMLImageElement>) {
  e.currentTarget.src = IMAGE_FALLBACK;
}

export default function About() {
  const ref = useReveal();
  const [video, setVideo] = useState<VideoItem | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!video) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setVideo(null);
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [video]);

  const copyRequisites = async () => {
    const text = REQUISITES.map((r) => `${r.label}: ${r.value}`).join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      /* клипборд недоступен — молча */
    }
  };

  return (
    <div ref={ref} className="mx-auto max-w-7xl px-4 sm:px-6 pt-12">
      {/* интро */}
      <section className="grid lg:grid-cols-[1fr_1.1fr] gap-10 items-center">
        <div>
          <p className="reveal text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">О нас</p>
          <h1 className="reveal mt-3 font-display uppercase text-3xl sm:text-5xl text-forge-100 leading-tight">
            Кузница, где металл <span className="text-ember-500">слушается рук</span>
          </h1>
          <div className="reveal spark-line w-24 mt-5" />
          <p className="reveal mt-5 text-[15px] leading-relaxed text-steel-300 max-w-xl">
            «Уфа-Ажурсталь» выросла из гаражной мастерской в полноценный цех
            художественной ковки. Мы не перепродаём штамповку: каждый завиток
            тянем из раскалённого квадрата, каждый шов варим сами и даём на
            него 5 лет гарантии.
          </p>
          <ul className="reveal mt-6 space-y-2.5 max-w-xl">
            {[
              "Собственное производство в Уфе — вы можете приехать и посмотреть на изделие в работе",
              "Договор, чек, фиксация цены на день заказа — никаких «подорожало по дороге»",
              "Сервис после гарантии: подкрасим, подтянем, приварим — как своим",
            ].map((t) => (
              <li key={t} className="flex items-start gap-2.5 text-[14px] text-steel-200">
                <Check className="w-4 h-4 mt-0.5 text-ember-400 shrink-0" /> {t}
              </li>
            ))}
          </ul>
        </div>

        <div className="reveal relative">
          <div className="plate chamfer p-2">
            <span className="rivet top-2.5 left-2.5" />
            <span className="rivet top-2.5 right-2.5" />
            <span className="rivet bottom-2.5 left-2.5" />
            <span className="rivet bottom-2.5 right-2.5" />
            <img
              src={FORGE_IMAGE}
              onError={onErrorImg}
              alt="Кузница Уфа-Ажурсталь"
              className="chamfer-sm w-full h-72 sm:h-96 object-cover"
            />
          </div>
          <div className="mt-5 grid grid-cols-3 gap-3">
            {NUMBERS.map((n) => (
              <div key={n.label} className="plate chamfer-sm px-3.5 py-3.5 text-center">
                <div className="font-display text-lg sm:text-xl text-ember-400">{n.value}</div>
                <div className="mt-1 text-[11px] leading-snug text-steel-400">{n.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* видео */}
      <section className="mt-20">
        <div className="reveal flex items-end justify-between gap-4 flex-wrap">
          <div>
            <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Видео</p>
            <h2 className="mt-3 font-display uppercase text-2xl sm:text-4xl text-forge-100">
              Наши работы <span className="text-ember-500">в движении</span>
            </h2>
          </div>
          <p className="text-sm text-steel-400 max-w-sm">
            Короткие ролики из цеха: как рождается изделие — от горна до отгрузки.
          </p>
        </div>

        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {VIDEOS.map((v) => (
            <button
              key={v.id}
              onClick={() => setVideo(v)}
              className="reveal group relative overflow-hidden plate chamfer text-left cursor-pointer product-card"
            >
              <img
                src={v.poster}
                onError={onErrorImg}
                alt={v.title}
                loading="lazy"
                className="product-img w-full h-52 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-iron-950/90 via-iron-950/25 to-transparent" />
              <span className="absolute inset-0 grid place-items-center">
                <span className="grid place-items-center w-14 h-14 rounded-full bg-ember-500 text-iron-950 shadow-[0_0_30px_rgba(232,132,31,0.65)] transition-transform duration-300 group-hover:scale-110">
                  <Play className="w-6 h-6 translate-x-0.5" fill="currentColor" />
                </span>
              </span>
              <span className="absolute top-3 right-3 chamfer-sm bg-iron-950/80 border border-iron-600 px-2 py-0.5 text-[11px] font-bold text-steel-200">
                {v.duration}
              </span>
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="font-display text-[15px] text-forge-100 leading-snug">{v.title}</h3>
                <p className="mt-1 text-[12px] text-steel-400">{v.note}</p>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* реквизиты и контакты */}
      <section className="mt-20 grid lg:grid-cols-[1.2fr_1fr] gap-6">
        <div className="reveal plate chamfer p-7 sm:p-8">
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Реквизиты</p>
              <h2 className="mt-2 font-display uppercase text-2xl text-forge-100">Для счетов и договоров</h2>
            </div>
            <button onClick={copyRequisites} className="btn-ghost btn-sm shrink-0">
              {copied ? <Check className="w-4 h-4 text-ember-400" /> : <Copy className="w-4 h-4" />}
              {copied ? "Скопировано" : "Копировать"}
            </button>
          </div>
          <dl className="mt-6 divide-y divide-iron-700">
            {REQUISITES.map((r) => (
              <div key={r.label} className="py-3 grid sm:grid-cols-[220px_1fr] gap-1 sm:gap-4">
                <dt className="text-[12px] uppercase tracking-wider font-bold text-steel-500 pt-0.5">{r.label}</dt>
                <dd className="text-[14px] text-steel-200">{r.value}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="flex flex-col gap-6">
          <div className="reveal plate chamfer p-7">
            <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Контакты</p>
            <h2 className="mt-2 font-display uppercase text-2xl text-forge-100">Приезжайте в цех</h2>
            <ul className="mt-5 space-y-3.5 text-[14px]">
              <li>
                <a href={CONTACTS.phoneHref} className="flex items-center gap-3 text-forge-100 hover:text-ember-300 transition-colors font-display text-lg">
                  <Phone className="w-4.5 h-4.5 text-ember-500 shrink-0" /> {CONTACTS.phone}
                </a>
                <a href={CONTACTS.phone2Href} className="mt-1 flex items-center gap-3 text-steel-300 hover:text-ember-300 transition-colors">
                  <Phone className="w-4.5 h-4.5 text-ember-500 shrink-0" /> {CONTACTS.phone2}
                </a>
              </li>
              <li>
                <a href={`mailto:${CONTACTS.email}`} className="flex items-center gap-3 text-steel-200 hover:text-ember-300 transition-colors">
                  <Mail className="w-4.5 h-4.5 text-ember-500 shrink-0" /> {CONTACTS.email}
                </a>
              </li>
              <li className="flex items-start gap-3 text-steel-300">
                <MapPin className="w-4.5 h-4.5 text-ember-500 shrink-0 mt-0.5" /> {CONTACTS.address}
              </li>
              <li className="flex items-start gap-3 text-steel-300">
                <Clock className="w-4.5 h-4.5 text-ember-500 shrink-0 mt-0.5" /> {CONTACTS.hours}
              </li>
            </ul>

            {/* стилизованная мини-карта */}
            <div className="relative mt-5 h-36 overflow-hidden chamfer-sm border border-iron-700 bg-iron-900">
              <svg viewBox="0 0 400 150" className="w-full h-full" preserveAspectRatio="none" aria-hidden="true">
                <rect width="400" height="150" fill="#15171b" />
                <path d="M0 100 L140 84 L260 96 L400 70" stroke="#3a414e" strokeWidth="10" fill="none" />
                <path d="M90 0 L110 150" stroke="#2b303a" strokeWidth="7" fill="none" />
                <path d="M300 0 L280 150" stroke="#2b303a" strokeWidth="7" fill="none" />
                <path d="M0 40 L400 30" stroke="#2b303a" strokeWidth="5" fill="none" />
                <circle cx="205" cy="90" r="26" fill="rgba(232,132,31,0.14)" />
                <circle cx="205" cy="90" r="8" fill="#e8841f" />
                <circle cx="205" cy="90" r="3" fill="#0f1013" />
              </svg>
              <span className="absolute bottom-2.5 left-3 text-[11px] uppercase tracking-[0.16em] font-bold text-steel-400 bg-iron-950/80 px-2.5 py-1 border border-iron-600 chamfer-sm">
                пр. Октября · ост. «Спортивная»
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* поставщикам и партнёрам */}
      <section className="mt-20">
        <div className="reveal text-center max-w-2xl mx-auto">
          <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Сотрудничество</p>
          <h2 className="mt-3 font-display uppercase text-2xl sm:text-4xl text-forge-100">
            Поставщикам и <span className="text-ember-500">партнёрам</span>
          </h2>
          <p className="mt-3 text-sm text-steel-400">
            Работаем по договору, платим вовремя, объёмы растём каждый сезон.
            Напишите напрямую — ответим в течение рабочего дня.
          </p>
        </div>

        <div className="mt-9 grid md:grid-cols-3 gap-5">
          {PARTNERS.map((p, i) => {
            const Icon = [Building2, Hammer, Users][i] ?? Hammer;
            return (
              <div key={p.id} className="reveal plate chamfer p-6 flex flex-col hover:border-ember-500/60 transition-colors duration-300">
                <span className="grid place-items-center w-11 h-11 chamfer-sm bg-iron-900 border border-iron-600 text-ember-400">
                  <Icon className="w-5 h-5" />
                </span>
                <h3 className="mt-4 font-display text-[16px] uppercase tracking-wide text-forge-100">{p.title}</h3>
                <p className="mt-1.5 text-[13px] text-steel-400">{p.person}</p>
                <ul className="mt-4 space-y-1.5 grow">
                  {p.points.map((pt) => (
                    <li key={pt} className="flex items-start gap-2 text-[13px] text-steel-300">
                      <Flame className="w-3.5 h-3.5 mt-0.5 text-ember-500 shrink-0" /> {pt}
                    </li>
                  ))}
                </ul>
                <div className="mt-5 pt-4 border-t border-iron-700 space-y-1.5 text-[13.5px]">
                  <a href={`tel:${p.phone.replace(/[^\d+]/g, "")}`} className="flex items-center gap-2.5 text-steel-200 hover:text-ember-300 transition-colors">
                    <Phone className="w-4 h-4 text-ember-500" /> {p.phone}
                  </a>
                  <a href={`mailto:${p.email}`} className="flex items-center gap-2.5 text-steel-200 hover:text-ember-300 transition-colors">
                    <Mail className="w-4 h-4 text-ember-500" /> {p.email}
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* видеомодалка */}
      {video && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4">
          <div className="absolute inset-0 bg-iron-950/92 backdrop-blur-sm fade-in" onClick={() => setVideo(null)} />
          <div className="modal-in relative w-full max-w-3xl">
            <button
              onClick={() => setVideo(null)}
              className="absolute -top-12 right-0 inline-flex items-center gap-2 text-steel-300 hover:text-ember-300 transition-colors cursor-pointer"
            >
              Закрыть <X className="w-5 h-5" />
            </button>
            <div className="plate chamfer p-2">
              <video
                src={video.src}
                poster={video.poster}
                controls
                autoPlay
                playsInline
                className="chamfer-sm w-full aspect-video object-cover bg-iron-950"
              />
            </div>
            <p className="mt-3 font-display text-forge-100">{video.title}</p>
            <p className="text-[13px] text-steel-400">{video.note}</p>
          </div>
        </div>
      )}
    </div>
  );
}
