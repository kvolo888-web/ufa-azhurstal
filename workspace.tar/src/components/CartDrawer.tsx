import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Banknote,
  Check,
  CreditCard,
  Flame,
  Landmark,
  Minus,
  PackageCheck,
  Plus,
  ShoppingCart,
  Trash2,
  Wallet,
  X,
} from "lucide-react";
import { IMAGE_FALLBACK, formatRub } from "../data/catalog";
import { useCart } from "../context/CartContext";

const DELIVERY_OPTIONS = [
  { id: "pickup", label: "Самовывоз из кузницы", note: "Уфа, пр. Октября, 132/3 — бесплатно", fee: 0 },
  { id: "city", label: "Доставка по Уфе", note: "1–3 дня, наша «Газель»", fee: 900 },
  { id: "tc", label: "Транспортная компания", note: "По России, тариф рассчитает менеджер", fee: 0 },
  { id: "manip", label: "Манипулятор + монтаж", note: "Для ворот, заборов, кроватей", fee: 3500 },
];

const PAYMENT_OPTIONS = [
  { id: "card", label: "Банковская карта онлайн", note: "Visa · MasterCard · Мир", icon: CreditCard },
  { id: "sbp", label: "СБП — оплата по QR-коду", note: "Без комиссии, мгновенно", icon: Wallet },
  { id: "invoice", label: "Безнал для юрлиц", note: "Счёт с НДС, закрывающие документы", icon: Landmark },
  { id: "cash", label: "При получении", note: "Наличными или картой курьеру", icon: Banknote },
];

type Step = "cart" | "form" | "done";

export default function CartDrawer() {
  const { items, isOpen, closeCart, setQty, removeItem, subtotal, clearCart } = useCart();
  const [step, setStep] = useState<Step>("cart");
  const [delivery, setDelivery] = useState("city");
  const [payment, setPayment] = useState("card");
  const [orderId, setOrderId] = useState("");
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "", comment: "" });
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});

  const justOrderedRef = useRef(false);

  useEffect(() => {
    if (isOpen) {
      // при открытии корзины возвращаемся к составу,
      // кроме случая «только что оформили заказ»
      if (justOrderedRef.current) justOrderedRef.current = false;
      else setStep("cart");

      const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeCart();
      document.addEventListener("keydown", onKey);
      document.body.style.overflow = "hidden";
      return () => {
        document.removeEventListener("keydown", onKey);
        document.body.style.overflow = "";
      };
    }
  }, [isOpen, closeCart]);

  const deliveryFee = DELIVERY_OPTIONS.find((d) => d.id === delivery)?.fee ?? 0;
  const total = useMemo(() => subtotal + deliveryFee, [subtotal, deliveryFee]);

  const submitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: { name?: string; phone?: string } = {};
    if (!form.name.trim()) nextErrors.name = "Укажите имя";
    if (form.phone.replace(/\D/g, "").length < 10) nextErrors.phone = "Укажите телефон полностью";
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;

    setOrderId("УА-2026-" + String(Math.floor(1000 + Math.random() * 9000)));
    justOrderedRef.current = true;
    setStep("done");
    clearCart();
  };

  if (!isOpen) return null;

  const doneDelivery = DELIVERY_OPTIONS.find((d) => d.id === delivery);
  const donePayment = PAYMENT_OPTIONS.find((p) => p.id === payment);

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-iron-950/80 backdrop-blur-sm fade-in" onClick={closeCart} />

      <aside className="drawer-in absolute right-0 top-0 h-full w-full max-w-md bg-iron-900 border-l border-iron-600 flex flex-col">
        {/* заголовок */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-iron-700 bg-iron-850/70">
          <h3 className="font-display uppercase text-forge-100 flex items-center gap-2.5">
            <Flame className="w-5 h-5 text-ember-500" />
            {step === "cart" && "Корзина"}
            {step === "form" && "Оформление заказа"}
            {step === "done" && "Заказ принят"}
          </h3>
          {step === "form" ? (
            <button onClick={() => setStep("cart")} className="btn-ghost btn-sm">
              <ArrowLeft className="w-4 h-4" /> Назад
            </button>
          ) : null}
          <button
            onClick={closeCart}
            className="grid place-items-center w-9 h-9 border border-iron-600 text-steel-300 hover:text-ember-300 hover:border-ember-500 transition-colors cursor-pointer"
            aria-label="Закрыть корзину"
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* ======= ШАГ 1: состав корзины ======= */}
        {step === "cart" && (
          <>
            <div className="grow overflow-y-auto px-5 py-4">
              {items.length === 0 ? (
                <div className="h-full grid place-items-center text-center py-10">
                  <div>
                    <ShoppingCart className="w-12 h-12 mx-auto text-iron-600" />
                    <p className="mt-4 font-display text-forge-100 uppercase">Пока пусто</p>
                    <p className="mt-2 text-[13px] text-steel-400 max-w-[220px] mx-auto">
                      Соберите мангал, ворота или кровать в конфигураторе — они появятся здесь.
                    </p>
                  </div>
                </div>
              ) : (
                <ul className="space-y-4">
                  {items.map((item) => (
                    <li key={item.key} className="plate chamfer-sm p-3.5 flex gap-3.5">
                      <img
                        src={item.image}
                        onError={(e) => (e.currentTarget.src = IMAGE_FALLBACK)}
                        alt={item.name}
                        className="w-20 h-20 object-cover shrink-0 border border-iron-700"
                      />
                      <div className="grow min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="font-bold text-[14px] text-forge-100 leading-snug">{item.name}</h4>
                          <button
                            onClick={() => removeItem(item.key)}
                            className="text-steel-500 hover:text-flame-500 transition-colors shrink-0 cursor-pointer"
                            aria-label="Удалить позицию"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                        {item.summary.length > 0 && (
                          <p className="mt-1 text-[11.5px] leading-relaxed text-steel-400 line-clamp-3">
                            {item.summary.join(" · ")}
                          </p>
                        )}
                        <div className="mt-2.5 flex items-center justify-between">
                          <div className="flex items-center border border-iron-600">
                            <button
                              onClick={() => setQty(item.key, item.qty - 1)}
                              className="px-2 py-1 text-steel-300 hover:text-ember-300 cursor-pointer"
                              aria-label="Меньше"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="w-6 text-center text-[13px] font-bold text-forge-100">{item.qty}</span>
                            <button
                              onClick={() => setQty(item.key, item.qty + 1)}
                              className="px-2 py-1 text-steel-300 hover:text-ember-300 cursor-pointer"
                              aria-label="Больше"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <span className="font-display text-[15px] text-ember-400">
                            {formatRub(item.unitPrice * item.qty)}
                          </span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {items.length > 0 && (
              <div className="border-t border-iron-700 bg-iron-850/80 px-5 py-4">
                <div className="flex justify-between text-[14px] text-steel-300">
                  <span>Товары</span>
                  <span className="font-bold text-forge-100">{formatRub(subtotal)}</span>
                </div>
                <p className="mt-1.5 text-[11.5px] text-steel-500">
                  Доставка выбирается на следующем шаге. От 50 000 ₽ по Уфе — бесплатно.
                </p>
                <button onClick={() => setStep("form")} className="btn-primary w-full mt-4">
                  Оформить заказ <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        )}

        {/* ======= ШАГ 2: оформление ======= */}
        {step === "form" && (
          <form onSubmit={submitOrder} className="grow overflow-y-auto flex flex-col">
            <div className="grow px-5 py-4 space-y-5">
              <div>
                <h4 className="text-[12px] uppercase tracking-[0.18em] font-bold text-steel-400">Контакты</h4>
                <div className="mt-2.5 grid gap-3">
                  <div>
                    <input
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Ваше имя *"
                      className={`field ${errors.name ? "border-flame-500!" : ""}`}
                    />
                    {errors.name && <p className="mt-1 text-[11.5px] text-flame-500">{errors.name}</p>}
                  </div>
                  <div>
                    <input
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="Телефон *"
                      className={`field ${errors.phone ? "border-flame-500!" : ""}`}
                    />
                    {errors.phone && <p className="mt-1 text-[11.5px] text-flame-500">{errors.phone}</p>}
                  </div>
                  <input
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="E-mail (необязательно)"
                    className="field"
                  />
                  <input
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    placeholder="Адрес доставки (если не самовывоз)"
                    className="field"
                  />
                  <textarea
                    value={form.comment}
                    onChange={(e) => setForm({ ...form, comment: e.target.value })}
                    placeholder="Комментарий кузнецу…"
                    className="field min-h-16 resize-y"
                  />
                </div>
              </div>

              <div>
                <h4 className="text-[12px] uppercase tracking-[0.18em] font-bold text-steel-400">Доставка</h4>
                <div className="mt-2.5 grid gap-2">
                  {DELIVERY_OPTIONS.map((d) => (
                    <label
                      key={d.id}
                      className={`flex items-center gap-3 px-4 py-3 border chamfer-sm cursor-pointer transition-all duration-200 ${
                        delivery === d.id
                          ? "border-ember-500 bg-ember-500/10"
                          : "border-iron-600 bg-iron-850 hover:border-steel-500"
                      }`}
                    >
                      <input
                        type="radio"
                        name="delivery"
                        checked={delivery === d.id}
                        onChange={() => setDelivery(d.id)}
                        className="accent-ember-500"
                      />
                      <span className="grow">
                        <span className="block font-bold text-[13.5px] text-forge-100">{d.label}</span>
                        <span className="block text-[11.5px] text-steel-500">{d.note}</span>
                      </span>
                      <span className="font-display text-[13px] text-ember-400 shrink-0">
                        {d.fee === 0 ? (d.id === "tc" ? "расчёт" : "0 ₽") : formatRub(d.fee)}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-[12px] uppercase tracking-[0.18em] font-bold text-steel-400">Оплата</h4>
                <div className="mt-2.5 grid grid-cols-1 gap-2">
                  {PAYMENT_OPTIONS.map((p) => (
                    <label
                      key={p.id}
                      className={`flex items-center gap-3 px-4 py-3 border chamfer-sm cursor-pointer transition-all duration-200 ${
                        payment === p.id
                          ? "border-ember-500 bg-ember-500/10"
                          : "border-iron-600 bg-iron-850 hover:border-steel-500"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        checked={payment === p.id}
                        onChange={() => setPayment(p.id)}
                        className="accent-ember-500"
                      />
                      <p.icon className={`w-5 h-5 shrink-0 ${payment === p.id ? "text-ember-400" : "text-steel-500"}`} />
                      <span className="grow">
                        <span className="block font-bold text-[13.5px] text-forge-100">{p.label}</span>
                        <span className="block text-[11.5px] text-steel-500">{p.note}</span>
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-t border-iron-700 bg-iron-850/80 px-5 py-4">
              <div className="space-y-1.5 text-[13.5px]">
                <div className="flex justify-between text-steel-300">
                  <span>Товары</span>
                  <span>{formatRub(subtotal)}</span>
                </div>
                <div className="flex justify-between text-steel-300">
                  <span>Доставка</span>
                  <span>{delivery === "tc" ? "рассчитает менеджер" : formatRub(deliveryFee)}</span>
                </div>
                <div className="flex justify-between pt-1.5 border-t border-iron-700">
                  <span className="font-bold text-forge-100">К оплате</span>
                  <span className="font-display text-xl text-ember-400">
                    {formatRub(total)}
                    {delivery === "tc" && <span className="text-[12px] text-steel-500 font-body"> + ТК</span>}
                  </span>
                </div>
              </div>
              <button type="submit" className="btn-primary w-full mt-4">
                <Check className="w-4 h-4" /> Подтвердить заказ
              </button>
              <p className="mt-2.5 text-[11px] text-steel-500 text-center">
                Менеджер перезвонит в течение 30 минут и пришлёт ссылку на оплату
              </p>
            </div>
          </form>
        )}

        {/* ======= ШАГ 3: успех ======= */}
        {step === "done" && (
          <div className="grow overflow-y-auto px-5 py-10 text-center fade-in">
            <span className="mx-auto grid place-items-center w-20 h-20 rounded-full bg-ember-500/15 border-2 border-ember-500 text-ember-400 shadow-[0_0_36px_-6px_rgba(232,132,31,0.7)]">
              <PackageCheck className="w-10 h-10" />
            </span>
            <h3 className="mt-6 font-display text-2xl uppercase text-forge-100">Заказ в работе!</h3>
            <p className="mt-2 font-display text-ember-400 text-lg">№ {orderId}</p>
            <p className="mt-3 text-[13.5px] leading-relaxed text-steel-400 max-w-xs mx-auto">
              Кузнец-менеджер свяжется с вами в течение 30 минут в рабочее время,
              подтвердит смету и отправит {donePayment ? donePayment.label.toLowerCase() : "ссылку на оплату"}.
            </p>

            <div className="mt-6 plate chamfer-sm p-4 text-left max-w-xs mx-auto space-y-2 text-[13px]">
              <div className="flex justify-between gap-3">
                <span className="text-steel-500">Получатель</span>
                <span className="font-bold text-forge-100 text-right">{form.name}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-steel-500">Телефон</span>
                <span className="font-bold text-forge-100 text-right">{form.phone}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-steel-500">Доставка</span>
                <span className="font-bold text-forge-100 text-right">{doneDelivery?.label}</span>
              </div>
              <div className="flex justify-between gap-3">
                <span className="text-steel-500">Оплата</span>
                <span className="font-bold text-forge-100 text-right">{donePayment?.label}</span>
              </div>
            </div>

            <button
              onClick={() => {
                closeCart();
                setStep("cart");
                setForm({ name: "", phone: "", email: "", address: "", comment: "" });
              }}
              className="btn-primary mt-7"
            >
              Продолжить покупки
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}
