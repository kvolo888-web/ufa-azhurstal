import { useEffect, useMemo, useState } from "react";
import { Check, Minus, Plus, ShoppingCart, X } from "lucide-react";
import {
  CATEGORIES,
  IMAGE_FALLBACK,
  computePrice,
  defaultConfig,
  formatRub,
  type Config,
  type Product,
} from "../data/catalog";
import { useCart } from "../context/CartContext";

function onErrorImg(e: React.SyntheticEvent<HTMLImageElement>) {
  e.currentTarget.src = IMAGE_FALLBACK;
}

export default function ConfiguratorModal({
  product,
  onClose,
}: {
  product: Product | null;
  onClose: () => void;
}) {
  const { addItem, openCart } = useCart();
  const [config, setConfig] = useState<Config>({});
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    if (product) {
      setConfig(defaultConfig(product));
      setQty(1);
      setAdded(false);
    }
  }, [product]);

  useEffect(() => {
    if (!product) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [product, onClose]);

  const price = useMemo(
    () => (product ? computePrice(product, config) : 0),
    [product, config]
  );

  if (!product) return null;

  const setSelect = (id: string, value: string) =>
    setConfig((c) => ({ ...c, [id]: value }));

  const toggleMulti = (id: string, value: string) =>
    setConfig((c) => {
      const picked = (c[id] as string[]) ?? [];
      return {
        ...c,
        [id]: picked.includes(value)
          ? picked.filter((v) => v !== value)
          : [...picked, value],
      };
    });

  const setNumber = (id: string, value: number) =>
    setConfig((c) => ({ ...c, [id]: value }));

  const handleAdd = () => {
    addItem(product, config, qty);
    setAdded(true);
    window.setTimeout(() => {
      onClose();
      openCart();
    }, 650);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-6">
      <div className="absolute inset-0 bg-iron-950/85 backdrop-blur-sm fade-in" onClick={onClose} />

      <div className="modal-in relative w-full max-w-5xl max-h-[94vh] sm:max-h-[88vh] bg-iron-900 border border-iron-600 chamfer overflow-hidden flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-20 grid place-items-center w-10 h-10 chamfer-sm bg-iron-950/80 border border-iron-600 text-steel-300 hover:text-ember-300 hover:border-ember-500 transition-colors cursor-pointer"
          aria-label="Закрыть"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid md:grid-cols-[0.85fr_1.15fr] grow overflow-hidden">
          {/* левая колонка: фото и описание */}
          <div className="relative hidden md:block">
            <img
              src={product.image}
              onError={onErrorImg}
              alt={product.name}
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-iron-950 via-iron-950/35 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <span className="text-[11px] uppercase tracking-[0.2em] font-bold text-ember-300">
                {CATEGORIES.find((c) => c.id === product.category)?.label}
              </span>
              <h3 className="mt-1.5 font-display text-2xl text-forge-100 leading-tight">
                {product.name}
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-steel-300">
                {product.description}
              </p>
            </div>
          </div>

          {/* правая колонка: опции */}
          <div className="flex flex-col overflow-hidden">
            <div className="md:hidden px-5 pt-5">
              <h3 className="font-display text-xl text-forge-100">{product.name}</h3>
              <p className="mt-1.5 text-[13px] text-steel-400">{product.description}</p>
            </div>

            <div className="grow overflow-y-auto px-5 sm:px-7 py-5 space-y-6">
              {product.options.map((opt) => (
                <fieldset key={opt.id}>
                  <legend className="text-[12px] uppercase tracking-[0.18em] font-bold text-steel-400">
                    {opt.label}
                  </legend>

                  {opt.kind === "select" && (
                    <div className="mt-2.5 grid gap-2">
                      {opt.values.map((v) => {
                        const active = config[opt.id] === v.id;
                        return (
                          <button
                            key={v.id}
                            onClick={() => setSelect(opt.id, v.id)}
                            className={`flex items-center justify-between gap-3 text-left px-4 py-3 border chamfer-sm transition-all duration-200 cursor-pointer ${
                              active
                                ? "border-ember-500 bg-ember-500/10 text-forge-100 shadow-[0_0_16px_-6px_rgba(232,132,31,0.6)]"
                                : "border-iron-600 bg-iron-850 text-steel-300 hover:border-steel-500"
                            }`}
                          >
                            <span>
                              <span className="block font-bold text-[14px]">{v.label}</span>
                              {v.dims && (
                                <span className="block text-[12px] text-steel-500 mt-0.5">{v.dims}</span>
                              )}
                            </span>
                            <span className="flex items-center gap-3 shrink-0">
                              {v.price > 0 && (
                                <span className={`text-[12.5px] font-bold ${active ? "text-ember-300" : "text-steel-500"}`}>
                                  +{formatRub(v.price)}
                                </span>
                              )}
                              <span
                                className={`grid place-items-center w-5 h-5 rounded-full border transition-colors ${
                                  active ? "border-ember-400 bg-ember-500 text-iron-950" : "border-iron-600"
                                }`}
                              >
                                {active && <Check className="w-3 h-3" />}
                              </span>
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {opt.kind === "multi" && (
                    <div className="mt-2.5 flex flex-wrap gap-2">
                      {opt.values.map((v) => {
                        const picked = ((config[opt.id] as string[]) ?? []).includes(v.id);
                        return (
                          <button
                            key={v.id}
                            onClick={() => toggleMulti(opt.id, v.id)}
                            className={`inline-flex items-center gap-2.5 px-3.5 py-2.5 border chamfer-sm text-[13px] font-semibold transition-all duration-200 cursor-pointer ${
                              picked
                                ? "border-ember-500 bg-ember-500/12 text-forge-100"
                                : "border-iron-600 bg-iron-850 text-steel-300 hover:border-steel-500"
                            }`}
                          >
                            <span
                              className={`grid place-items-center w-4.5 h-4.5 border transition-colors ${
                                picked ? "bg-ember-500 border-ember-500 text-iron-950" : "border-iron-600"
                              }`}
                            >
                              {picked && <Check className="w-3 h-3" />}
                            </span>
                            {v.label}
                            <span className={picked ? "text-ember-300" : "text-steel-500"}>
                              +{formatRub(v.price)}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {opt.kind === "number" && (
                    <div className="mt-3 plate chamfer-sm p-4">
                      <div className="flex items-center justify-between">
                        <button
                          onClick={() => setNumber(opt.id, Math.max(opt.min, ((config[opt.id] as number) ?? opt.min) - opt.step))}
                          className="grid place-items-center w-9 h-9 border border-iron-600 text-steel-200 hover:border-ember-500 hover:text-ember-300 transition-colors cursor-pointer"
                          aria-label="Уменьшить"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <div className="text-center">
                          <span className="font-display text-2xl text-ember-400">
                            {(config[opt.id] as number) ?? opt.min}
                          </span>
                          <span className="ml-1.5 text-[13px] text-steel-400">{opt.unit}</span>
                        </div>
                        <button
                          onClick={() => setNumber(opt.id, Math.min(opt.max, ((config[opt.id] as number) ?? opt.min) + opt.step))}
                          className="grid place-items-center w-9 h-9 border border-iron-600 text-steel-200 hover:border-ember-500 hover:text-ember-300 transition-colors cursor-pointer"
                          aria-label="Увеличить"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                      <input
                        type="range"
                        min={opt.min}
                        max={opt.max}
                        step={opt.step}
                        value={(config[opt.id] as number) ?? opt.min}
                        onChange={(e) => setNumber(opt.id, Number(e.target.value))}
                        className="w-full mt-3"
                        aria-label={opt.label}
                      />
                      <div className="mt-1 flex justify-between text-[11px] text-steel-500">
                        <span>от {opt.min} {opt.unit}</span>
                        <span>до {opt.max} {opt.unit}</span>
                      </div>
                    </div>
                  )}
                </fieldset>
              ))}
            </div>

            {/* нижняя панель с ценой */}
            <div className="border-t border-iron-700 bg-iron-850/90 px-5 sm:px-7 py-4">
              <div className="flex flex-wrap items-center gap-4">
                <div className="mr-auto">
                  <div className="text-[11px] uppercase tracking-wider font-bold text-steel-500">
                    Итого за комплектацию
                  </div>
                  <div className="font-display text-[26px] leading-tight text-ember-400">
                    {formatRub(price * qty)}
                  </div>
                  {qty > 1 && (
                    <div className="text-[11.5px] text-steel-500">
                      {qty} × {formatRub(price)}
                    </div>
                  )}
                </div>

                <div className="flex items-center border border-iron-600 chamfer-sm">
                  <button
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="px-3 py-2.5 text-steel-300 hover:text-ember-300 cursor-pointer"
                    aria-label="Меньше"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-display text-forge-100">{qty}</span>
                  <button
                    onClick={() => setQty((q) => Math.min(99, q + 1))}
                    className="px-3 py-2.5 text-steel-300 hover:text-ember-300 cursor-pointer"
                    aria-label="Больше"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <button onClick={handleAdd} disabled={added} className="btn-primary">
                  {added ? (
                    <>
                      <Check className="w-4 h-4" /> Добавлено
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4" /> В корзину
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
