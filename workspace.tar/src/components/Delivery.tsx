import { useState } from "react";
import {
  Building2,
  ChevronDown,
  FileCheck,
  Hammer,
  MapPin,
  Package,
  PhoneCall,
  ShieldCheck,
  Truck,
  Wrench,
} from "lucide-react";
import { DELIVERY_FAQ, DELIVERY_METHODS } from "../data/content";
import { useReveal } from "../hooks/useReveal";

const METHOD_ICONS: Record<string, typeof Truck> = {
  pickup: Building2,
  city: Truck,
  region: MapPin,
  tc: Package,
  manip: Wrench,
};

const ORDER_STEPS = [
  { icon: FileCheck, title: "Заявка", text: "Оформляете заказ на сайте или по телефону" },
  { icon: Hammer, title: "Производство", text: "Куём, красим, упаковываем — фотоотчёт в мессенджер" },
  { icon: PhoneCall, title: "Звонок логиста", text: "Согласуем день и интервал доставки за сутки" },
  { icon: Truck, title: "Получение", text: "Осмотрите изделие при курьере — оплата после проверки" },
];

const MOUNT_POINTS = [
  "Бурение и бетонирование столбов под ворота и заборы",
  "Навеска, регулировка петель, настройка автоматики",
  "Сборка кроватей и качелей у вас дома за 30–60 минут",
  "Уборка площадки после работ — оставляем чисто",
];

export default function Delivery() {
  const ref = useReveal();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div ref={ref} className="mx-auto max-w-7xl px-4 sm:px-6 pt-12">
      {/* интро */}
      <section className="max-w-3xl">
        <p className="reveal text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Доставка</p>
        <h1 className="reveal mt-3 font-display uppercase text-3xl sm:text-5xl text-forge-100 leading-tight">
          Привезём хоть <span className="text-ember-500">за Урал</span>
        </h1>
        <div className="reveal spark-line w-24 mt-5" />
        <p className="reveal mt-5 text-[15px] leading-relaxed text-steel-300">
          Кованое изделие — груз ответственный: тяжёлый, с покраской, часто
          нестандартный. Поэтому возим сами и проверенными перевозчиками,
          пакуем в плёнку и картон, а крупногабарит — с манипулятором.
          Выбирайте вариант ниже.
        </p>
      </section>

      {/* способы доставки */}
      <section className="mt-10 grid md:grid-cols-2 xl:grid-cols-3 gap-5">
        {DELIVERY_METHODS.map((m) => {
          const Icon = METHOD_ICONS[m.id] ?? Truck;
          return (
            <article key={m.id} className="reveal plate chamfer p-6 flex flex-col hover:border-ember-500/60 transition-colors duration-300 group">
              <div className="flex items-start justify-between gap-3">
                <span className="grid place-items-center w-12 h-12 chamfer-sm bg-iron-900 border border-iron-600 text-ember-400 group-hover:bg-ember-500 group-hover:text-iron-950 transition-colors duration-300">
                  <Icon className="w-5.5 h-5.5" />
                </span>
                <span className="chamfer-sm bg-iron-900 border border-iron-600 px-2.5 py-1 text-[11px] font-bold text-steel-300">
                  {m.time}
                </span>
              </div>
              <h3 className="mt-4 font-display text-[17px] uppercase tracking-wide text-forge-100">{m.title}</h3>
              <p className="mt-1.5 font-bold text-[14px] text-ember-400">{m.price}</p>
              <p className="mt-2.5 text-[13px] leading-relaxed text-steel-400 grow">{m.detail}</p>
            </article>
          );
        })}

        {/* монтаж */}
        <article className="reveal plate chamfer p-6 relative overflow-hidden md:col-span-2 xl:col-span-1 bg-gradient-to-br from-iron-850 to-ember-600/15">
          <div className="flex items-start justify-between gap-3">
            <span className="grid place-items-center w-12 h-12 chamfer-sm bg-ember-500 text-iron-950">
              <ShieldCheck className="w-5.5 h-5.5" />
            </span>
            <span className="chamfer-sm bg-ember-500 text-iron-950 px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide">
              Гарантия 12 мес
            </span>
          </div>
          <h3 className="mt-4 font-display text-[17px] uppercase tracking-wide text-forge-100">Монтаж под ключ</h3>
          <p className="mt-1.5 font-bold text-[14px] text-ember-400">от 2 500 ₽ за изделие</p>
          <ul className="mt-3 space-y-1.5">
            {MOUNT_POINTS.map((p) => (
              <li key={p} className="flex items-start gap-2 text-[12.5px] leading-snug text-steel-300">
                <Hammer className="w-3.5 h-3.5 mt-0.5 text-ember-400 shrink-0" /> {p}
              </li>
            ))}
          </ul>
        </article>
      </section>

      {/* как проходит доставка */}
      <section className="mt-20">
        <h2 className="reveal font-display uppercase text-2xl sm:text-3xl text-forge-100">
          Путь изделия <span className="text-ember-500">до вашей калитки</span>
        </h2>
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {ORDER_STEPS.map((s, i) => (
            <div key={s.title} className="reveal plate chamfer-sm p-5 relative">
              <span className="absolute -top-3 -left-2 font-display text-4xl text-iron-700 select-none">0{i + 1}</span>
              <s.icon className="w-6 h-6 text-ember-400" />
              <h4 className="mt-3 font-display text-[14px] uppercase tracking-wide text-forge-100">{s.title}</h4>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-steel-400">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="mt-20 max-w-3xl">
        <h2 className="reveal font-display uppercase text-2xl sm:text-3xl text-forge-100">
          Частые <span className="text-ember-500">вопросы</span>
        </h2>
        <div className="mt-6 space-y-3">
          {DELIVERY_FAQ.map((f, i) => {
            const open = openFaq === i;
            return (
              <div key={f.q} className="reveal plate chamfer-sm overflow-hidden">
                <button
                  onClick={() => setOpenFaq(open ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left cursor-pointer group"
                >
                  <span className={`font-bold text-[14.5px] transition-colors ${open ? "text-ember-300" : "text-forge-100 group-hover:text-ember-300"}`}>
                    {f.q}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 shrink-0 text-ember-400 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
                  />
                </button>
                <div
                  className="grid transition-all duration-300 ease-out"
                  style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-[13.5px] leading-relaxed text-steel-400">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
