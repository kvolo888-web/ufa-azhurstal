import { Clock, Mail, MapPin, Phone } from "lucide-react";
import Logo from "./Logo";
import type { NavigateFn } from "./Header";
import { CONTACTS } from "../data/content";

export default function Footer({ onNavigate }: { onNavigate: NavigateFn }) {
  return (
    <footer className="mt-24 border-t border-iron-700 bg-iron-900/80">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-14 grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <div className="flex items-center gap-3">
            <Logo size={46} />
            <span className="font-display text-xl text-forge-100">
              Уфа-<span className="text-ember-400">Ажурсталь</span>
            </span>
          </div>
          <p className="mt-4 text-sm leading-relaxed text-steel-400 max-w-xs">
            Кузница полного цикла: от эскиза до монтажа. Кованые мангалы,
            ворота, заборы, качели, кровати и каминные наборы — вручную,
            с гарантией на швы 5 лет.
          </p>
          <p className="mt-4 text-[12px] text-steel-500">
            ИП Гареев Р. Р. · ИНН 027415682340
          </p>
        </div>

        <div>
          <h4 className="font-display text-[13px] uppercase tracking-[0.18em] text-forge-100">
            Разделы
          </h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {(
              [
                ["home", "Главная и каталог"],
                ["about", "О нас"],
                ["reviews", "Отзывы клиентов"],
                ["delivery", "Доставка и монтаж"],
              ] as const
            ).map(([p, label]) => (
              <li key={p}>
                <button
                  onClick={() => onNavigate(p)}
                  className="text-steel-400 hover:text-ember-300 transition-colors cursor-pointer"
                >
                  {label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-[13px] uppercase tracking-[0.18em] text-forge-100">
            Изделия
          </h4>
          <ul className="mt-4 space-y-2.5 text-sm text-steel-400">
            {[
              "Мангалы и казаны",
              "Ворота и калитки",
              "Заборы и секции",
              "Качели",
              "Кровати",
              "Каминные наборы",
              "Вешалки",
            ].map((t) => (
              <li key={t}>
                <button
                  onClick={() => onNavigate("home", "catalog")}
                  className="hover:text-ember-300 transition-colors cursor-pointer"
                >
                  {t}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-[13px] uppercase tracking-[0.18em] text-forge-100">
            Контакты
          </h4>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              <a href={CONTACTS.phoneHref} className="flex items-start gap-2.5 text-steel-200 hover:text-ember-300 transition-colors">
                <Phone className="w-4 h-4 mt-0.5 text-ember-500 shrink-0" />
                <span>
                  {CONTACTS.phone}
                  <br />
                  {CONTACTS.phone2}
                </span>
              </a>
            </li>
            <li>
              <a href={`mailto:${CONTACTS.email}`} className="flex items-center gap-2.5 text-steel-200 hover:text-ember-300 transition-colors">
                <Mail className="w-4 h-4 text-ember-500 shrink-0" />
                {CONTACTS.email}
              </a>
            </li>
            <li className="flex items-start gap-2.5 text-steel-400">
              <MapPin className="w-4 h-4 mt-0.5 text-ember-500 shrink-0" />
              {CONTACTS.address}
            </li>
            <li className="flex items-start gap-2.5 text-steel-400">
              <Clock className="w-4 h-4 mt-0.5 text-ember-500 shrink-0" />
              {CONTACTS.hours}
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-iron-800">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-[12px] text-steel-500">
          <span>© 2009–2026 «Уфа-Ажурсталь». Ковано в Башкортостане.</span>
          <span>Цены на сайте не являются публичной офертой.</span>
        </div>
      </div>
    </footer>
  );
}
