import { useEffect, useState } from "react";
import { Mail, Menu, Phone, ShoppingCart, X } from "lucide-react";
import Logo from "./Logo";
import { useCart } from "../context/CartContext";
import { CONTACTS } from "../data/content";

export type Page = "home" | "about" | "reviews" | "delivery";
export type NavigateFn = (page: Page, anchor?: string) => void;

export const NAV: { id: Page; label: string }[] = [
  { id: "home", label: "Главная" },
  { id: "about", label: "О нас" },
  { id: "reviews", label: "Отзывы" },
  { id: "delivery", label: "Доставка" },
];

export default function Header({
  page,
  onNavigate,
}: {
  page: Page;
  onNavigate: NavigateFn;
}) {
  const { count, openCart } = useCart();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (p: Page) => {
    setMenuOpen(false);
    onNavigate(p);
  };

  return (
    <header
      className={`sticky top-0 z-40 border-b transition-all duration-300 ${
        scrolled
          ? "bg-iron-950/92 border-iron-700 shadow-[0_10px_30px_-12px_rgba(0,0,0,0.8)] backdrop-blur-md"
          : "bg-iron-950/70 border-transparent backdrop-blur-sm"
      }`}
    >
      {/* верхняя строка: логотип, название, телефон, почта */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex items-center justify-between gap-4 py-3">
          <button
            onClick={() => go("home")}
            className="group flex items-center gap-3 text-left cursor-pointer"
            aria-label="На главную"
          >
            <Logo size={52} className="shrink-0 transition-transform duration-300 group-hover:rotate-[8deg]" />
            <span>
              <span className="block font-display text-xl sm:text-2xl leading-none text-forge-100 tracking-wide">
                Уфа-<span className="text-ember-400">Ажурсталь</span>
              </span>
              <span className="mt-1 block text-[11px] uppercase tracking-[0.22em] text-steel-400 font-semibold">
                Художественная ковка · Уфа
              </span>
            </span>
          </button>

          <div className="flex items-center gap-5">
            <div className="hidden md:block text-right">
              <a
                href={CONTACTS.phoneHref}
                className="flex items-center justify-end gap-2 font-display text-lg text-forge-100 hover:text-ember-300 transition-colors"
              >
                <Phone className="w-4 h-4 text-ember-500" />
                {CONTACTS.phone}
              </a>
              <a
                href={`mailto:${CONTACTS.email}`}
                className="mt-0.5 flex items-center justify-end gap-2 text-[13px] text-steel-400 hover:text-ember-300 transition-colors"
              >
                <Mail className="w-3.5 h-3.5 text-ember-500" />
                {CONTACTS.email}
              </a>
            </div>

            {/* корзина */}
            <button
              onClick={openCart}
              className="relative inline-flex items-center gap-2 border border-iron-600 hover:border-ember-500 bg-iron-850 hover:bg-iron-800 px-3.5 py-2.5 chamfer-sm transition-all duration-200 cursor-pointer group"
              aria-label="Открыть корзину"
            >
              <ShoppingCart className="w-5 h-5 text-steel-200 group-hover:text-ember-300 transition-colors" />
              <span className="hidden sm:inline font-display text-[13px] uppercase tracking-wide text-steel-200 group-hover:text-ember-300 transition-colors">
                Корзина
              </span>
              {count > 0 && (
                <span className="absolute -top-2 -right-2 min-w-5 h-5 px-1 grid place-items-center rounded-full bg-ember-500 text-iron-950 text-[11px] font-extrabold shadow-[0_0_14px_rgba(232,132,31,0.7)]">
                  {count}
                </span>
              )}
            </button>

            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="lg:hidden p-2 border border-iron-600 chamfer-sm text-steel-200 hover:text-ember-300 cursor-pointer"
              aria-label="Меню"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* навигация по вкладкам */}
      <nav className="border-t border-iron-800 bg-iron-900/60">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 hidden lg:flex items-center gap-1">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => go(item.id)}
              className={`relative px-5 py-3 font-display text-[13px] uppercase tracking-[0.14em] transition-colors duration-200 cursor-pointer ${
                page === item.id
                  ? "text-ember-400"
                  : "text-steel-300 hover:text-forge-100"
              }`}
            >
              {item.label}
              <span
                className={`spark-line absolute left-4 right-4 -bottom-px transition-opacity duration-300 ${
                  page === item.id ? "opacity-100" : "opacity-0"
                }`}
              />
            </button>
          ))}
          <span className="ml-auto flex items-center gap-2 text-[12px] text-steel-500">
            <span className="w-1.5 h-1.5 rounded-full bg-ember-500 ember-glow" />
            Кузница работает: {CONTACTS.hours.split("·")[0]}
          </span>
        </div>
      </nav>

      {/* мобильное меню */}
      {menuOpen && (
        <div className="lg:hidden border-t border-iron-800 bg-iron-900 fade-in">
          <div className="mx-auto max-w-7xl px-4 py-3 flex flex-col">
            {NAV.map((item) => (
              <button
                key={item.id}
                onClick={() => go(item.id)}
                className={`text-left px-3 py-3 font-display text-sm uppercase tracking-widest border-b border-iron-800 last:border-0 cursor-pointer ${
                  page === item.id ? "text-ember-400" : "text-steel-200"
                }`}
              >
                {item.label}
              </button>
            ))}
            <a
              href={CONTACTS.phoneHref}
              className="mt-3 flex items-center gap-2 font-display text-lg text-ember-300"
            >
              <Phone className="w-4 h-4" /> {CONTACTS.phone}
            </a>
            <a
              href={`mailto:${CONTACTS.email}`}
              className="mt-1 flex items-center gap-2 text-sm text-steel-400"
            >
              <Mail className="w-4 h-4" /> {CONTACTS.email}
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
