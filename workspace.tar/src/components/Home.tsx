import { useMemo, useState } from "react";
import {
  ArrowRight,
  Flame,
  Paintbrush,
  PenTool,
  Plus,
  Ruler,
  Send,
  ShoppingCart,
  Sparkles,
  Truck,
  Check,
} from "lucide-react";
import {
  CATEGORIES,
  FORGE_IMAGE,
  IMAGE_FALLBACK,
  PRODUCTS,
  formatRub,
  type Product,
} from "../data/catalog";
import { useCart } from "../context/CartContext";
import { useReveal } from "../hooks/useReveal";
import type { NavigateFn } from "./Header";

/* детерминированные «искры» для hero */
const SPARKS = [
  { left: "12%", delay: "0s", dur: "3.1s", sx: "18px" },
  { left: "22%", delay: "0.9s", dur: "3.8s", sx: "-14px" },
  { left: "35%", delay: "1.7s", dur: "2.9s", sx: "10px" },
  { left: "48%", delay: "0.4s", dur: "3.5s", sx: "22px" },
  { left: "60%", delay: "2.2s", dur: "3.2s", sx: "-18px" },
  { left: "71%", delay: "1.2s", dur: "3.9s", sx: "12px" },
  { left: "83%", delay: "0.6s", dur: "3s", sx: "-10px" },
  { left: "91%", delay: "1.9s", dur: "3.6s", sx: "16px" },
];

const MARQUEE = [
  "Мангалы", "Ворота", "Калитки", "Заборы", "Качели",
  "Каминные наборы", "Кровати", "Вешалки", "Кочерги", "Индивидуальные заказы",
];

const STATS = [
  { value: "16", unit: "лет", label: "у горна и наковальни" },
  { value: "3 400", unit: "+", label: "выполненных заказов" },
  { value: "5", unit: "лет", label: "гарантии на сварные швы" },
];

const STEPS = [
  { icon: PenTool, title: "Эскиз и смета", text: "Замер, 3D-макет и точная цена за 1 день. Правки — бесплатно." },
  { icon: Flame, title: "Ковка", text: "Греем, тянем, крутим. Каждый завиток — вручную, на открытом огне." },
  { icon: Paintbrush, title: "Покраска", text: "Пескоструй, грунт-эмаль 3в1 или порошковая камера, патина на выбор." },
  { icon: Truck, title: "Доставка и монтаж", text: "Привезём по России, установим под ключ. Гарантия на монтаж 12 мес." },
];

function onErrorImg(e: React.SyntheticEvent<HTMLImageElement>) {
  e.currentTarget.src = IMAGE_FALLBACK;
}

export default function Home({
  onConfigure,
  onNavigate,
}: {
  onConfigure: (p: Product) => void;
  onNavigate: NavigateFn;
}) {
  const ref = useReveal();
  const { addItem } = useCart();
  const [category, setCategory] = useState("all");
  const [orderSent, setOrderSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", idea: "" });

  const visible = useMemo(
    () => (category === "all" ? PRODUCTS : PRODUCTS.filter((p) => p.category === category)),
    [category]
  );

  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  const submitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.name.trim() && form.phone.trim()) setOrderSent(true);
  };

  return (
    <div ref={ref}>
      {/* ======================= HERO ======================= */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-12 pb-16 lg:pt-16 lg:pb-20 grid lg:grid-cols-[1.05fr_1fr] gap-10 items-center">
          <div>
            <p className="reveal inline-flex items-center gap-2.5 text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">
              <Flame className="w-4 h-4" />
              Кузница полного цикла · Уфа · с 2009 года
            </p>
            <h1
              className="reveal mt-5 font-display text-forge-100 uppercase leading-[1.04] text-[42px] sm:text-6xl xl:text-[72px]"
            >
              Металл,
              <br />
              которому
              <br />
              <span className="text-ember-500">дали характер</span>
            </h1>
            <div className="reveal spark-line w-28 mt-6" />
            <p className="reveal mt-6 max-w-xl text-lg leading-relaxed text-steel-300">
              Кованые мангалы, ворота, заборы, качели, кровати и каминные
              наборы. Соберите изделие под себя — размер, узор, элементы —
              а цена пересчитается сразу, без «менеджер вам перезвонит».
            </p>
            <div className="reveal mt-8 flex flex-wrap gap-4">
              <button onClick={() => scrollTo("catalog")} className="btn-primary">
                Смотреть каталог <ArrowRight className="w-4 h-4" />
              </button>
              <button onClick={() => scrollTo("custom")} className="btn-ghost">
                Индивидуальный заказ
              </button>
            </div>

            <div className="reveal mt-12 grid grid-cols-3 gap-4 max-w-lg">
              {STATS.map((s) => (
                <div key={s.label} className="plate chamfer-sm px-4 py-4">
                  <div className="font-display text-2xl sm:text-3xl text-ember-400">
                    {s.value}
                    <span className="text-steel-400 text-lg">{s.unit}</span>
                  </div>
                  <div className="mt-1 text-[12px] leading-snug text-steel-400">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* фото кузницы с искрами */}
          <div className="reveal relative">
            <div className="absolute -inset-4 bg-[radial-gradient(closest-side,rgba(232,132,31,0.22),transparent)] blur-2xl ember-glow" />
            <div className="relative plate chamfer p-2">
              <span className="rivet top-2.5 left-2.5" />
              <span className="rivet top-2.5 right-2.5" />
              <span className="rivet bottom-2.5 left-2.5" />
              <span className="rivet bottom-2.5 right-2.5" />
              <div className="relative overflow-hidden chamfer-sm">
                <img
                  src={FORGE_IMAGE}
                  onError={onErrorImg}
                  alt="Кузнец за работой в кузнице Уфа-Ажурсталь"
                  className="w-full h-[320px] sm:h-[420px] lg:h-[500px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-iron-950/80 via-transparent to-iron-950/20" />
                {SPARKS.map((s, i) => (
                  <span
                    key={i}
                    className="spark"
                    style={
                      {
                        left: s.left,
                        bottom: "8%",
                        animationDelay: s.delay,
                        "--dur": s.dur,
                        "--sx": s.sx,
                      } as React.CSSProperties
                    }
                  />
                ))}
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between gap-3">
                  <span className="chamfer-sm bg-iron-950/80 border border-iron-600 px-4 py-2 text-[12px] uppercase tracking-[0.18em] text-steel-300">
                    Наш цех · пр. Октября, 132/3
                  </span>
                  <span className="floaty chamfer-sm bg-ember-500 text-iron-950 font-display text-[12px] uppercase tracking-wide px-3.5 py-2">
                    Ковка на глазах
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* бегущая строка */}
        <div className="marquee border-y border-iron-700 bg-iron-900/80 overflow-hidden">
          <div className="marquee-track flex w-max items-center gap-8 py-3.5 pr-8">
            {[...MARQUEE, ...MARQUEE].map((word, i) => (
              <span key={i} className="flex items-center gap-8 whitespace-nowrap">
                <span className="font-display text-[13px] uppercase tracking-[0.22em] text-steel-400">
                  {word}
                </span>
                <Sparkles className="w-3.5 h-3.5 text-ember-500" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ======================= КАТАЛОГ ======================= */}
      <section id="catalog" className="mx-auto max-w-7xl px-4 sm:px-6 pt-16 scroll-mt-28">
        <div className="reveal flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">
              Каталог изделий
            </p>
            <h2 className="mt-3 font-display uppercase text-3xl sm:text-5xl text-forge-100 leading-tight">
              Что куём <span className="text-ember-500">прямо сейчас</span>
            </h2>
            <div className="spark-line w-24 mt-4" />
          </div>
          <p className="max-w-md text-sm leading-relaxed text-steel-400">
            Каждая карточка — конструктор: форма, размеры, узоры и
            дополнительные элементы. Цена обновляется при каждом выборе.
          </p>
        </div>

        {/* фильтры */}
        <div className="reveal mt-8 flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              className={`chamfer-sm px-4 py-2 text-[13px] font-bold tracking-wide transition-all duration-200 cursor-pointer ${
                category === c.id
                  ? "bg-ember-500 text-iron-950 shadow-[0_0_18px_-4px_rgba(232,132,31,0.8)]"
                  : "bg-iron-850 border border-iron-600 text-steel-300 hover:border-ember-500 hover:text-ember-300"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* сетка товаров */}
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {visible.map((p) => (
            <article key={p.id} className="product-card reveal plate chamfer flex flex-col overflow-hidden">
              <div className="relative overflow-hidden">
                <img
                  src={p.image}
                  onError={onErrorImg}
                  alt={p.name}
                  loading="lazy"
                  className="product-img w-full h-56 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-iron-950/70 to-transparent" />
                {p.badge && (
                  <span className="absolute top-3 left-3 chamfer-sm bg-ember-500 text-iron-950 text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1">
                    {p.badge}
                  </span>
                )}
                <button
                  onClick={() => {
                    addItem(p, Object.fromEntries(
                      p.options.map((o) => [
                        o.id,
                        o.kind === "select" ? o.values[0].id : o.kind === "multi" ? [] : o.min,
                      ])
                    ), 1);
                  }}
                  title="Быстро в корзину (базовая комплектация)"
                  aria-label={`Добавить ${p.name} в корзину`}
                  className="absolute top-3 right-3 grid place-items-center w-10 h-10 chamfer-sm bg-iron-950/85 border border-iron-600 text-steel-200 hover:text-iron-950 hover:bg-ember-400 hover:border-ember-400 transition-all duration-200 cursor-pointer"
                >
                  <ShoppingCart className="w-4.5 h-4.5" />
                </button>
                <span className="absolute bottom-3 left-3 text-[11px] uppercase tracking-[0.18em] text-steel-300 font-bold">
                  {CATEGORIES.find((c) => c.id === p.category)?.label}
                </span>
              </div>

              <div className="flex flex-col grow p-5">
                <h3 className="font-display text-lg text-forge-100 leading-snug">{p.name}</h3>
                <p className="mt-2 text-[13px] leading-relaxed text-steel-400 line-clamp-2 grow">
                  {p.description}
                </p>
                <div className="mt-4 flex items-end justify-between gap-3">
                  <div>
                    <div className="text-[11px] uppercase tracking-wider text-steel-500 font-bold">
                      {p.priceNote ? `от ${formatRub(p.basePrice)} ${p.priceNote}` : "от"}
                    </div>
                    <div className="font-display text-2xl text-ember-400">
                      {formatRub(p.basePrice)}
                    </div>
                  </div>
                  <button onClick={() => onConfigure(p)} className="btn-primary btn-sm">
                    <Ruler className="w-4 h-4" /> Собрать
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* ======================= КОНФИГУРАТОР ======================= */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <div className="reveal plate chamfer overflow-hidden grid lg:grid-cols-[1fr_auto]">
          <span className="rivet top-3 left-3" />
          <span className="rivet top-3 right-3" />
          <span className="rivet bottom-3 left-3" />
          <span className="rivet bottom-3 right-3" />
          <div className="p-8 sm:p-10">
            <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">
              Честный конфигуратор
            </p>
            <h3 className="mt-3 font-display uppercase text-2xl sm:text-4xl text-forge-100 leading-tight max-w-2xl">
              Меняйте размеры, узоры и элементы —{" "}
              <span className="text-ember-500">цена пересчитается мгновенно</span>
            </h3>
            <div className="mt-6 grid sm:grid-cols-3 gap-4 max-w-3xl">
              {[
                { icon: Ruler, t: "Форма и размеры", d: "Для мангалов и кроватей — форма корпуса и спального места" },
                { icon: Sparkles, t: "Секции и узоры", d: "Для заборов — число секций, рисунок заполнения, высота" },
                { icon: Plus, t: "Доп. элементы", d: "Крыша, автоматика, патина, полки — что угодно к базе" },
              ].map((f) => (
                <div key={f.t} className="bg-iron-900/70 border border-iron-700 chamfer-sm p-4">
                  <f.icon className="w-5 h-5 text-ember-400" />
                  <div className="mt-2.5 font-bold text-[14px] text-forge-100">{f.t}</div>
                  <div className="mt-1 text-[12.5px] leading-snug text-steel-400">{f.d}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="hidden lg:flex items-stretch border-l border-iron-700 bg-gradient-to-b from-ember-600/20 to-transparent">
            <button
              onClick={() => scrollTo("catalog")}
              className="btn-primary m-auto mx-8 whitespace-nowrap"
            >
              Открыть каталог <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* ======================= ЭТАПЫ ======================= */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 mt-20">
        <div className="reveal text-center">
          <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Как мы работаем</p>
          <h2 className="mt-3 font-display uppercase text-3xl sm:text-4xl text-forge-100">
            От эскиза до <span className="text-ember-500">первой искры у вас дома</span>
          </h2>
        </div>
        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {STEPS.map((s, i) => (
            <div key={s.title} className="reveal plate chamfer-sm p-6 relative group hover:border-ember-500/60 transition-colors duration-300">
              <div className="flex items-center justify-between">
                <span className="grid place-items-center w-11 h-11 chamfer-sm bg-iron-900 border border-iron-600 text-ember-400 group-hover:bg-ember-500 group-hover:text-iron-950 transition-colors duration-300">
                  <s.icon className="w-5 h-5" />
                </span>
                <span className="font-display text-3xl text-iron-700 group-hover:text-ember-600 transition-colors duration-300">
                  0{i + 1}
                </span>
              </div>
              <h4 className="mt-4 font-display text-[15px] uppercase tracking-wide text-forge-100">{s.title}</h4>
              <p className="mt-2 text-[13px] leading-relaxed text-steel-400">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ======================= ИНДИВИДУАЛЬНЫЙ ЗАКАЗ ======================= */}
      <section id="custom" className="mx-auto max-w-7xl px-4 sm:px-6 mt-20 scroll-mt-28">
        <div className="reveal grid lg:grid-cols-2 gap-8 items-stretch">
          <div className="relative overflow-hidden plate chamfer p-8 sm:p-10">
            <div className="absolute -top-16 -right-16 w-64 h-64 bg-[radial-gradient(closest-side,rgba(232,132,31,0.25),transparent)] ember-glow" />
            <p className="text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">
              Нет в каталоге?
            </p>
            <h3 className="mt-3 font-display uppercase text-2xl sm:text-4xl text-forge-100 leading-tight">
              Куём по вашим эскизам, фото и даже салфетке
            </h3>
            <p className="mt-4 text-[14.5px] leading-relaxed text-steel-300 max-w-md">
              Линейка постоянно растёт: вчера был только мангал, сегодня — уже
              беседка с печью. Опишите, что нужно, — за день пришлём эскиз и смету.
            </p>
            <ul className="mt-6 space-y-2.5">
              {[
                "Бесплатный замер по Уфе и пригороду",
                "3D-эскиз до запуска в работу",
                "Договор, чек, гарантия 24 месяца",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-[14px] text-steel-200">
                  <Check className="w-4 h-4 mt-0.5 text-ember-400 shrink-0" /> {t}
                </li>
              ))}
            </ul>
          </div>

          <form onSubmit={submitOrder} className="plate chamfer p-8 sm:p-10 flex flex-col">
            {orderSent ? (
              <div className="m-auto text-center py-8 fade-in">
                <span className="mx-auto grid place-items-center w-16 h-16 rounded-full bg-ember-500/15 border border-ember-500 text-ember-400">
                  <Check className="w-8 h-8" />
                </span>
                <h4 className="mt-5 font-display text-xl text-forge-100 uppercase">Заявка в горне!</h4>
                <p className="mt-2 text-sm text-steel-400 max-w-xs mx-auto">
                  Кузнец-менеджер позвонит в течение 30 минут в рабочее время и
                  уточнит детали по эскизу.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setOrderSent(false);
                    setForm({ name: "", phone: "", idea: "" });
                  }}
                  className="btn-ghost btn-sm mt-6"
                >
                  Отправить ещё одну
                </button>
              </div>
            ) : (
              <>
                <h4 className="font-display text-lg uppercase text-forge-100">Оставить заявку</h4>
                <label className="mt-5 block">
                  <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Ваше имя *</span>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="field mt-1.5"
                    placeholder="Как к вам обращаться"
                  />
                </label>
                <label className="mt-4 block">
                  <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Телефон *</span>
                  <input
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="field mt-1.5"
                    placeholder="+7 ___ ___-__-__"
                  />
                </label>
                <label className="mt-4 block grow">
                  <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Что выковать?</span>
                  <textarea
                    value={form.idea}
                    onChange={(e) => setForm({ ...form, idea: e.target.value })}
                    className="field mt-1.5 min-h-24 resize-y"
                    placeholder="Например: беседка 3×3 с мангалом внутри, есть фото-пример…"
                  />
                </label>
                <button type="submit" className="btn-primary mt-6 w-full">
                  <Send className="w-4 h-4" /> Отправить кузнецу
                </button>
                <p className="mt-3 text-[11.5px] text-steel-500 text-center">
                  Нажимая кнопку, вы соглашаетесь на обработку персональных данных
                </p>
              </>
            )}
          </form>
        </div>

        {/* мини-CTA в отзывы/доставку */}
        <div className="reveal mt-16 grid sm:grid-cols-2 gap-5">
          <button
            onClick={() => onNavigate("reviews")}
            className="plate chamfer-sm p-6 text-left flex items-center gap-5 hover:border-ember-500/60 transition-all duration-300 cursor-pointer group"
          >
            <span className="font-display text-4xl text-ember-500">4,9</span>
            <span>
              <span className="block font-display uppercase text-forge-100 group-hover:text-ember-300 transition-colors">
                127 отзывов клиентов
              </span>
              <span className="block mt-1 text-[13px] text-steel-400">
                Читайте, что говорят о воротах, мангалах и кроватях →
              </span>
            </span>
          </button>
          <button
            onClick={() => onNavigate("delivery")}
            className="plate chamfer-sm p-6 text-left flex items-center gap-5 hover:border-ember-500/60 transition-all duration-300 cursor-pointer group"
          >
            <Truck className="w-9 h-9 text-ember-500" />
            <span>
              <span className="block font-display uppercase text-forge-100 group-hover:text-ember-300 transition-colors">
                Доставка по всей России
              </span>
              <span className="block mt-1 text-[13px] text-steel-400">
                По Уфе от 50 000 ₽ — бесплатно, монтаж под ключ →
              </span>
            </span>
          </button>
        </div>
      </section>
    </div>
  );
}
