type LogoProps = { size?: number; className?: string };

/**
 * Фирменный знак «Уфа-Ажурсталь»: стальная пластина со срезанными
 * углами, внутри — подкова горячим креплением и искры из горна.
 */
export default function Logo({ size = 52, className = "" }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="logoEmber" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f39c3d" />
          <stop offset="100%" stopColor="#d94f22" />
        </linearGradient>
        <linearGradient id="logoSteel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#cfd5e0" />
          <stop offset="100%" stopColor="#8a93a3" />
        </linearGradient>
      </defs>

      {/* пластина */}
      <path
        d="M14 2 H50 L62 14 V50 L50 62 H14 L2 50 V14 Z"
        fill="#1a1d23"
        stroke="url(#logoEmber)"
        strokeWidth="2.4"
      />
      <path
        d="M17 8 H47 L56 17 V47 L47 56 H17 L8 47 V17 Z"
        fill="none"
        stroke="#3a414e"
        strokeWidth="1.2"
      />

      {/* заклёпки */}
      <circle cx="10" cy="10" r="1.6" fill="#6b7484" />
      <circle cx="54" cy="10" r="1.6" fill="#6b7484" />
      <circle cx="10" cy="54" r="1.6" fill="#6b7484" />
      <circle cx="54" cy="54" r="1.6" fill="#6b7484" />

      {/* подкова */}
      <path
        d="M20 46 C14 36 14 24 22 18 C27 14.5 37 14.5 42 18 C50 24 50 36 44 46"
        stroke="url(#logoSteel)"
        strokeWidth="5.4"
        strokeLinecap="round"
      />
      {/* отверстия под гвозди */}
      <circle cx="20.5" cy="40" r="1.5" fill="#0f1013" />
      <circle cx="17.6" cy="30" r="1.5" fill="#0f1013" />
      <circle cx="43.5" cy="40" r="1.5" fill="#0f1013" />
      <circle cx="46.4" cy="30" r="1.5" fill="#0f1013" />

      {/* искра в центре */}
      <path
        d="M32 24 L34.6 30.4 L32 37 L29.4 30.4 Z"
        fill="url(#logoEmber)"
      />
      <circle cx="32" cy="43" r="1.4" fill="#f39c3d" />
    </svg>
  );
}
