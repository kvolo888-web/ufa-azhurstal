import { useMemo, useState } from "react";
import { Check, Quote, Star } from "lucide-react";
import { INITIAL_REVIEWS, type Review } from "../data/content";
import { PRODUCTS } from "../data/catalog";
import { useReveal } from "../hooks/useReveal";

const BARS = [
  { stars: 5, width: "88%" },
  { stars: 4, width: "9%" },
  { stars: 3, width: "2%" },
  { stars: 2, width: "1%" },
  { stars: 1, width: "0%" },
];

function Stars({ value, size = "w-4 h-4" }: { value: number; size?: string }) {
  return (
    <span className="inline-flex gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={`${size} ${i <= value ? "text-ember-400" : "text-iron-600"}`}
          fill={i <= value ? "currentColor" : "none"}
        />
      ))}
    </span>
  );
}

export default function Reviews() {
  const ref = useReveal();
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", product: PRODUCTS[0].name, rating: 5, text: "" });

  const average = useMemo(
    () => (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1).replace(".", ","),
    [reviews]
  );

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !form.text.trim()) return;
    setReviews((prev) => [
      {
        id: Date.now(),
        name: form.name.trim(),
        product: form.product,
        rating: form.rating,
        date: new Date().toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: "numeric" }),
        text: form.text.trim(),
      },
      ...prev,
    ]);
    setSent(true);
    setForm({ name: "", product: PRODUCTS[0].name, rating: 5, text: "" });
    window.setTimeout(() => setSent(false), 4000);
  };

  return (
    <div ref={ref} className="mx-auto max-w-7xl px-4 sm:px-6 pt-12">
      {/* сводка */}
      <section className="grid lg:grid-cols-[1fr_auto] gap-8 items-end">
        <div>
          <p className="reveal text-[12px] font-bold uppercase tracking-[0.24em] text-ember-300">Отзывы</p>
          <h1 className="reveal mt-3 font-display uppercase text-3xl sm:text-5xl text-forge-100 leading-tight">
            Слово — клиентам, <span className="text-ember-500">железо — нам</span>
          </h1>
          <div className="reveal spark-line w-24 mt-5" />
        </div>

        <div className="reveal plate chamfer px-7 py-6 flex items-center gap-6">
          <div>
            <div className="font-display text-5xl text-ember-400">{average}</div>
            <Stars value={5} size="w-4.5 h-4.5" />
          </div>
          <div className="w-44 space-y-1.5">
            {BARS.map((b) => (
              <div key={b.stars} className="flex items-center gap-2">
                <span className="text-[11px] font-bold text-steel-500 w-3">{b.stars}</span>
                <div className="grow h-1.5 bg-iron-700 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-ember-600 to-ember-400" style={{ width: b.width }} />
                </div>
              </div>
            ))}
            <p className="text-[11.5px] text-steel-500 pt-1">{reviews.length + 118} отзывов с 2009 года</p>
          </div>
        </div>
      </section>

      {/* карточки отзывов */}
      <section className="mt-10 grid md:grid-cols-2 xl:grid-cols-3 gap-5">
        {reviews.map((r) => (
          <article key={r.id} className="reveal plate chamfer-sm p-6 flex flex-col hover:border-ember-500/50 transition-colors duration-300">
            <div className="flex items-start justify-between gap-3">
              <Quote className="w-7 h-7 text-iron-600" fill="currentColor" />
              <Stars value={r.rating} />
            </div>
            <p className="mt-3 text-[14px] leading-relaxed text-steel-200 grow">{r.text}</p>
            <div className="mt-5 pt-4 border-t border-iron-700 flex items-center justify-between gap-3">
              <div>
                <div className="font-bold text-[14px] text-forge-100">{r.name}</div>
                <div className="text-[11.5px] text-steel-500 mt-0.5">{r.date}</div>
              </div>
              <span className="chamfer-sm bg-iron-900 border border-iron-600 px-2.5 py-1 text-[11px] font-bold text-ember-300 max-w-[45%] truncate">
                {r.product}
              </span>
            </div>
          </article>
        ))}
      </section>

      {/* форма отзыва */}
      <section className="mt-16 max-w-3xl mx-auto">
        <div className="reveal plate chamfer p-8 relative overflow-hidden">
          <div className="absolute -top-14 -right-14 w-52 h-52 bg-[radial-gradient(closest-side,rgba(232,132,31,0.2),transparent)] ember-glow" />
          <h2 className="font-display uppercase text-2xl text-forge-100">
            Получили заказ? <span className="text-ember-500">Расскажите, как вам</span>
          </h2>
          <p className="mt-2 text-[13.5px] text-steel-400">
            Честные отзывы помогают соседям решиться, а нам — держать планку.
          </p>

          {sent && (
            <div className="mt-4 flex items-center gap-2.5 text-ember-300 text-[13.5px] font-bold fade-in">
              <Check className="w-4.5 h-4.5" /> Спасибо! Отзыв уже на странице.
            </div>
          )}

          <form onSubmit={submit} className="mt-6 grid sm:grid-cols-2 gap-4">
            <label className="block">
              <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Ваше имя *</span>
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="field mt-1.5"
                placeholder="Иван Петров"
              />
            </label>
            <label className="block">
              <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Что заказывали</span>
              <select
                value={form.product}
                onChange={(e) => setForm({ ...form, product: e.target.value })}
                className="field mt-1.5"
              >
                {PRODUCTS.map((p) => (
                  <option key={p.id} value={p.name} className="bg-iron-900">
                    {p.name}
                  </option>
                ))}
                <option value="Индивидуальный заказ" className="bg-iron-900">
                  Индивидуальный заказ
                </option>
              </select>
            </label>
            <div className="sm:col-span-2 flex items-center gap-3">
              <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Оценка:</span>
              <span className="flex gap-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setForm({ ...form, rating: i })}
                    aria-label={`Оценка ${i}`}
                    className="transition-transform duration-150 hover:scale-125 cursor-pointer"
                  >
                    <Star
                      className={`w-6 h-6 ${i <= form.rating ? "text-ember-400" : "text-iron-600"}`}
                      fill={i <= form.rating ? "currentColor" : "none"}
                    />
                  </button>
                ))}
              </span>
            </div>
            <label className="block sm:col-span-2">
              <span className="text-[12px] uppercase tracking-wider font-bold text-steel-400">Отзыв *</span>
              <textarea
                required
                value={form.text}
                onChange={(e) => setForm({ ...form, text: e.target.value })}
                className="field mt-1.5 min-h-24 resize-y"
                placeholder="Как прошло общение, что понравилось, что улучшить…"
              />
            </label>
            <button type="submit" className="btn-primary sm:col-span-2 justify-self-start">
              Опубликовать отзыв
            </button>
          </form>
        </div>
      </section>
    </div>
  );
}
