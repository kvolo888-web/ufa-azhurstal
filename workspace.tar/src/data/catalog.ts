/* ============================================================
   КАТАЛОГ «Уфа-Ажурсталь»
   Линейка товаров легко расширяется: добавьте объект в массив
   PRODUCTS — карточка на главной, конфигуратор и корзина
   подстроятся автоматически.
   ============================================================ */

export type SelectValue = {
  id: string;
  label: string;
  dims?: string; // размеры / пояснение
  price: number; // доплата к базовой цене, ₽
};

export type ProductOption =
  | {
      kind: "select"; // одиночный выбор (форма, размер, узор…)
      id: string;
      label: string;
      values: SelectValue[];
      /** доплата умножается на количество секций (для заборов) */
      perSection?: boolean;
    }
  | {
      kind: "multi"; // множественный выбор: дополнительные элементы
      id: string;
      label: string;
      values: SelectValue[];
    }
  | {
      kind: "number"; // числовой параметр: секции, крючки…
      id: string;
      label: string;
      min: number;
      max: number;
      step: number;
      unit: string; // «секций», «крючков»
      unitPrice: number; // цена за единицу сверх минимума
    };

export type Product = {
  id: string;
  name: string;
  category: string;
  basePrice: number; // цена базовой комплектации, ₽
  priceNote?: string; // «за секцию», «за комплект»
  image: string;
  description: string;
  badge?: string;
  options: ProductOption[];
};

export type Config = Record<string, string | string[] | number>;

export const CATEGORIES = [
  { id: "all", label: "Все изделия" },
  { id: "mangal", label: "Мангалы и казаны" },
  { id: "hearth", label: "Очаг и камин" },
  { id: "gates", label: "Ворота, калитки, заборы" },
  { id: "garden", label: "Сад и двор" },
  { id: "bedroom", label: "Спальня" },
  { id: "interior", label: "Интерьер" },
];

const IMG = {
  mangal: "https://image.qwenlm.ai/generated-images/fd34bc52-28eb-47c4-ada9-c4983c6828c3/_result.png",
  kocherga: "https://image.qwenlm.ai/generated-images/f4718418-af44-4c2e-9c98-5358132dc75b/_result.png",
  vorota: "https://image.qwenlm.ai/generated-images/9d3a6fc5-b891-4ac9-8aae-10e0db27b213/_result.png",
  kalitka: "https://image.qwenlm.ai/generated-images/2b3ee179-1477-4e13-9d69-49dbe23a7a0b/_result.png",
  kacheli: "https://image.qwenlm.ai/generated-images/42b66735-b10d-44d7-ab7c-9b9e8e86e347/_result.png",
  kamin: "https://image.qwenlm.ai/generated-images/d0df4754-cd13-4c84-a8c2-effa77cbfd11/_result.png",
  krovat: "https://image.qwenlm.ai/generated-images/3f1965e8-644b-4ef4-a62a-f0f4f5f74d53/_result.png",
  veshalka: "https://image.qwenlm.ai/generated-images/c4d7e42d-a565-47ed-af75-98f9f2d51e26/_result.png",
  zabor: "https://image.qwenlm.ai/generated-images/9b4edd77-0f1e-4215-9f99-9aea8c4b8c5c/_result.png",
};

export const FORGE_IMAGE =
  "https://image.qwenlm.ai/generated-images/9ddf25f8-dcd4-49d0-b05a-25727c2b6c66/_result.png";

export const PRODUCTS: Product[] = [
  {
    id: "mangal",
    name: "Мангал «Жар-птица»",
    category: "mangal",
    basePrice: 8900,
    image: IMG.mangal,
    badge: "Хит продаж",
    description:
      "Сталь 3 мм, проваренный корпус, кованые завитки и ножки. Держит жар до 6 часов, не ведёт от температуры.",
    options: [
      {
        kind: "select",
        id: "form",
        label: "Форма корпуса",
        values: [
          { id: "classic", label: "Классический короб", price: 0 },
          { id: "barrel", label: "Бочка", dims: "из цельнотянутой трубы Ø325", price: 2600 },
          { id: "kazan", label: "С очагом под казан", dims: "чугунная плита Ø360", price: 4500 },
        ],
      },
      {
        kind: "select",
        id: "size",
        label: "Размер жаровни",
        values: [
          { id: "s", label: "Компакт", dims: "600 × 350 мм, до 6 шампуров", price: 0 },
          { id: "m", label: "Стандарт", dims: "800 × 400 мм, до 9 шампуров", price: 1400 },
          { id: "l", label: "Большой", dims: "1000 × 500 мм, до 12 шампуров", price: 3000 },
        ],
      },
      {
        kind: "multi",
        id: "extras",
        label: "Дополнительные элементы",
        values: [
          { id: "roof", label: "Крыша с дымоходом", price: 3800 },
          { id: "shelves", label: "Боковые столики", price: 1900 },
          { id: "holder", label: "Держатель шампуров", price: 950 },
          { id: "box", label: "Дровник-ящик", price: 2400 },
          { id: "wheels", label: "Колёса и ручка", price: 1200 },
        ],
      },
    ],
  },
  {
    id: "kocherga",
    name: "Кочерга «Огнёвка»",
    category: "hearth",
    basePrice: 1900,
    image: IMG.kocherga,
    description:
      "Ручная ковка, кручёный прут Ø14 мм. Сбалансирована по весу — рука не устаёт даже у большого очага.",
    options: [
      {
        kind: "select",
        id: "length",
        label: "Длина",
        values: [
          { id: "55", label: "550 мм", dims: "для камина", price: 0 },
          { id: "70", label: "700 мм", dims: "универсальная", price: 300 },
          { id: "85", label: "850 мм", dims: "для бани и печи", price: 600 },
        ],
      },
      {
        kind: "select",
        id: "handle",
        label: "Рукоять",
        values: [
          { id: "forged", label: "Кованая, кручёная", price: 0 },
          { id: "oak", label: "Дуб, латунная втулка", price: 450 },
          { id: "leather", label: "Оплётка кожей", price: 700 },
        ],
      },
    ],
  },
  {
    id: "kamin",
    name: "Каминный набор «У огня»",
    category: "hearth",
    basePrice: 7400,
    image: IMG.kamin,
    badge: "Ручная работа",
    description:
      "Кочерга, щипцы, совок и метла на кованой подставке. Единый рисунок ручки — соберём комплект под ваш камин.",
    options: [
      {
        kind: "select",
        id: "set",
        label: "Состав набора",
        values: [
          { id: "3", label: "3 предмета", dims: "кочерга, совок, метла", price: 0 },
          { id: "4", label: "4 предмета", dims: "+ щипцы для углей", price: 1900 },
          { id: "5", label: "5 предметов", dims: "+ щипцы для дров", price: 3400 },
        ],
      },
      {
        kind: "select",
        id: "stand",
        label: "Подставка",
        values: [
          { id: "classic", label: "Классическая стойка", price: 0 },
          { id: "twist", label: "Кручёная стойка", price: 1200 },
          { id: "base", label: "С кованым основанием", dims: "дубовая полка", price: 2100 },
        ],
      },
      {
        kind: "multi",
        id: "finish",
        label: "Отделка",
        values: [
          { id: "patina", label: "Патина «старая бронза»", price: 900 },
          { id: "copper", label: "Меднение", price: 1600 },
        ],
      },
    ],
  },
  {
    id: "vorota",
    name: "Ворота «Родовые»",
    category: "gates",
    basePrice: 96000,
    priceNote: "за створ",
    image: IMG.vorota,
    badge: "Под монтаж",
    description:
      "Каркас из трубы 60×40, заполнение — квадрат 14 мм с художественными элементами. Грунт-эмаль 3 в 1, любая палитра RAL.",
    options: [
      {
        kind: "select",
        id: "type",
        label: "Тип ворот",
        values: [
          { id: "swing", label: "Распашные", price: 0 },
          { id: "slide", label: "Откатные", dims: "балка 71 мм, роликовые опоры", price: 42000 },
        ],
      },
      {
        kind: "select",
        id: "size",
        label: "Размер проёма",
        values: [
          { id: "30", label: "3,0 × 1,8 м", price: 0 },
          { id: "35", label: "3,5 × 1,8 м", price: 9000 },
          { id: "40", label: "4,0 × 2,0 м", price: 18000 },
        ],
      },
      {
        kind: "multi",
        id: "extras",
        label: "Оснащение",
        values: [
          { id: "auto", label: "Автоматика CAME (2 привода)", price: 38000 },
          { id: "wicket", label: "Встроенная калитка", price: 16500 },
          { id: "monogram", label: "Вензель / герб семьи", price: 4800 },
          { id: "lamps", label: "Сигнальная лампа + фотоэлементы", price: 6200 },
        ],
      },
    ],
  },
  {
    id: "kalitka",
    name: "Калитка «Узорочье»",
    category: "gates",
    basePrice: 28500,
    image: IMG.kalitka,
    description:
      "Рама 40×40, ажурное заполнение, регулируемые петли на подшипнике. В комплекте — ответная планка и наличники.",
    options: [
      {
        kind: "select",
        id: "size",
        label: "Размер",
        values: [
          { id: "10", label: "1,0 × 1,8 м", price: 0 },
          { id: "11", label: "1,1 × 2,0 м", price: 2200 },
          { id: "12", label: "1,2 × 2,0 м", dims: "усиленная рама", price: 3800 },
        ],
      },
      {
        kind: "select",
        id: "lock",
        label: "Замок",
        values: [
          { id: "mortise", label: "Врезной «Гардиан»", price: 0 },
          { id: "electro", label: "Электромеханический", dims: "для домофона", price: 6400 },
        ],
      },
      {
        kind: "multi",
        id: "extras",
        label: "Дополнительно",
        values: [
          { id: "visor", label: "Козырёк над калиткой", price: 5600 },
          { id: "monogram", label: "Вензель или номер дома", price: 2400 },
          { id: "bell", label: "Кованый звонок-кольцо", price: 1100 },
        ],
      },
    ],
  },
  {
    id: "zabor",
    name: "Забор «Ажурный»",
    category: "gates",
    basePrice: 8200,
    priceNote: "за секцию",
    image: IMG.zabor,
    badge: "Секции × N",
    description:
      "Секция на каркасе 40×25 с художественным заполнением. Собираем забор любой длины — цена пересчитается по числу секций.",
    options: [
      {
        kind: "number",
        id: "sections",
        label: "Количество секций",
        min: 1,
        max: 60,
        step: 1,
        unit: "секций",
        unitPrice: 8200,
      },
      {
        kind: "select",
        id: "size",
        label: "Размер секции",
        perSection: true,
        values: [
          { id: "2515", label: "2,5 × 1,5 м", price: 0 },
          { id: "2518", label: "2,5 × 1,8 м", price: 1400 },
          { id: "3020", label: "3,0 × 2,0 м", price: 3200 },
        ],
      },
      {
        kind: "select",
        id: "pattern",
        label: "Рисунок заполнения",
        perSection: true,
        values: [
          { id: "classic", label: "Классика с пиками", price: 0 },
          { id: "grid", label: "Решётка с ромбом", price: 900 },
          { id: "vine", label: "Виноградная лоза", price: 1800 },
          { id: "monogram", label: "С вензелем", price: 2600 },
        ],
      },
      {
        kind: "multi",
        id: "extras",
        label: "К забору",
        values: [
          { id: "pillars", label: "Столбы с ковкой (за шт.)", price: 3900 },
          { id: "gate", label: "Комплект ворот в едином стиле", price: 84000 },
        ],
      },
    ],
  },
  {
    id: "kacheli",
    name: "Качели «Закат»",
    category: "garden",
    basePrice: 26500,
    image: IMG.kacheli,
    badge: "Сезон 2026",
    description:
      "Каркас из трубы 51 мм на подшипниковых подвесах. Выдерживают до 280 кг, не скрипят даже на пятом году.",
    options: [
      {
        kind: "select",
        id: "form",
        label: "Форма и вместимость",
        values: [
          { id: "single", label: "Одноместные", dims: "сиденье 700 мм", price: 0 },
          { id: "double", label: "Двухместные", dims: "сиденье 1200 мм", price: 6000 },
          { id: "bench", label: "Скамья-качели", dims: "1500 мм, со спинкой-дугой", price: 11500 },
        ],
      },
      {
        kind: "multi",
        id: "extras",
        label: "Комфорт",
        values: [
          { id: "canopy", label: "Кованый козырёк с поликарбонатом", price: 4200 },
          { id: "cushions", label: "Мягкие подушки (3 шт.)", price: 2500 },
          { id: "net", label: "Москитный полог", price: 1800 },
        ],
      },
    ],
  },
  {
    id: "krovat",
    name: "Кровать «Ажурная ночь»",
    category: "bedroom",
    basePrice: 24900,
    image: IMG.krovat,
    description:
      "Спинки из квадрата 12 мм с объёмными завитками, ламели — берёза. Основание выдерживает 400 кг без деформации.",
    options: [
      {
        kind: "select",
        id: "form",
        label: "Форма изголовья",
        values: [
          { id: "straight", label: "Прямое", price: 0 },
          { id: "arch", label: "Арочное", dims: "высота 1350 мм", price: 2500 },
          { id: "bald", label: "С кованым балдахином", dims: "4 стойки, дуги", price: 9800 },
        ],
      },
      {
        kind: "select",
        id: "size",
        label: "Спальное место",
        values: [
          { id: "90", label: "90 × 200", price: 0 },
          { id: "120", label: "120 × 200", price: 2200 },
          { id: "140", label: "140 × 200", price: 3600 },
          { id: "160", label: "160 × 200", price: 4900 },
        ],
      },
      {
        kind: "multi",
        id: "extras",
        label: "Детали",
        values: [
          { id: "patina", label: "Патина «серебро» или «золото»", price: 1800 },
          { id: "brass", label: "Латунные вставки", price: 3200 },
          { id: "shelf", label: "Прикроватная кованая полка", price: 2600 },
        ],
      },
    ],
  },
  {
    id: "veshalka",
    name: "Вешалка «Крыло»",
    category: "interior",
    basePrice: 5600,
    image: IMG.veshalka,
    description:
      "Напольная или настенная, крючки горячим креплением — не разболтаются никогда. Порошковая окраска в любой цвет.",
    options: [
      {
        kind: "select",
        id: "type",
        label: "Тип",
        values: [
          { id: "floor", label: "Напольная", dims: "высота 1750 мм", price: 0 },
          { id: "wall", label: "Настенная", dims: "ширина 800 мм", price: 0 },
        ],
      },
      {
        kind: "number",
        id: "hooks",
        label: "Количество крючков",
        min: 4,
        max: 12,
        step: 1,
        unit: "крючков",
        unitPrice: 160,
      },
      {
        kind: "multi",
        id: "extras",
        label: "Дополнительно",
        values: [
          { id: "mirror", label: "Зеркало в кованой раме", price: 1900 },
          { id: "shelf", label: "Полка для шапок", price: 1100 },
          { id: "stand", label: "Подставка под зонты", price: 800 },
        ],
      },
    ],
  },
];

/* ---------------- расчёт конфигурации и цены ---------------- */

export function defaultConfig(product: Product): Config {
  const cfg: Config = {};
  for (const opt of product.options) {
    if (opt.kind === "select") cfg[opt.id] = opt.values[0].id;
    else if (opt.kind === "multi") cfg[opt.id] = [];
    else cfg[opt.id] = opt.min;
  }
  return cfg;
}

export function computePrice(product: Product, cfg: Config): number {
  let total = product.basePrice;
  const sectionsRaw = cfg["sections"];
  const sections =
    typeof sectionsRaw === "number" ? sectionsRaw : 1;

  for (const opt of product.options) {
    if (opt.kind === "select") {
      const value = opt.values.find((v) => v.id === cfg[opt.id]);
      let delta = value?.price ?? 0;
      if (opt.perSection) delta *= sections;
      total += delta;
    } else if (opt.kind === "multi") {
      const picked = (cfg[opt.id] as string[]) ?? [];
      total += opt.values
        .filter((v) => picked.includes(v.id))
        .reduce((sum, v) => sum + v.price, 0);
    } else {
      const value = (cfg[opt.id] as number) ?? opt.min;
      total += Math.max(0, value - opt.min) * opt.unitPrice;
    }
  }
  return total;
}

/** Текстовое описание выбранной комплектации — для корзины и заказа */
export function describeConfig(product: Product, cfg: Config): string[] {
  const lines: string[] = [];
  for (const opt of product.options) {
    if (opt.kind === "select") {
      const value = opt.values.find((v) => v.id === cfg[opt.id]);
      if (value && value.id !== opt.values[0].id) {
        lines.push(`${opt.label}: ${value.label}${value.dims ? ` (${value.dims})` : ""}`);
      }
    } else if (opt.kind === "multi") {
      const picked = (cfg[opt.id] as string[]) ?? [];
      opt.values
        .filter((v) => picked.includes(v.id))
        .forEach((v) => lines.push(`+ ${v.label}`));
    } else {
      const value = (cfg[opt.id] as number) ?? opt.min;
      lines.push(`${value} ${opt.unit}`);
    }
  }
  return lines;
}

export function formatRub(n: number): string {
  return n.toLocaleString("ru-RU") + " ₽";
}

/** SVG-заглушка, если внешняя картинка не загрузится */
export const IMAGE_FALLBACK =
  "data:image/svg+xml," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'><rect width='800' height='600' fill='#1a1d23'/><rect x='16' y='16' width='768' height='568' fill='none' stroke='#3a414e' stroke-width='2'/><path d='M400 210c-70 0-105 60-96 130 4 30 16 55 34 70 6-42 24-66 62-66s56 24 62 66c18-15 30-40 34-70 9-70-26-130-96-130z' fill='none' stroke='#e8841f' stroke-width='10' stroke-linecap='round'/><text x='400' y='470' font-family='Arial' font-size='26' fill='#67707f' text-anchor='middle'>Уфа-Ажурсталь</text></svg>`
  );
